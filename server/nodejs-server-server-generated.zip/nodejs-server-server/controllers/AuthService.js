'use strict';

exports.account = function(args, res, next) {
  /**
   * Finds Pets by params
   * Multiple status values can be provided with comma separated strings
   *
   * api_key String API KEY
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "firstName" : "aeiou",
  "lastName" : "aeiou",
  "password" : "aeiou",
  "userStatus" : 6,
  "phone" : "aeiou",
  "id" : 0,
  "email" : "aeiou",
  "username" : "aeiou"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.dashboard = function(args, res, next) {
  /**
   * Finds Pets by tags
   * Muliple tags can be provided with comma separated strings. Use         tag1, tag2, tag3 for testing.
   *
   * api_key String API KEY
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "petId" : 6,
  "quantity" : 1,
  "id" : 0,
  "shipDate" : "2000-01-23T04:56:07.000+00:00",
  "complete" : false,
  "status" : "placed"
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.getI18n = function(args, res, next) {
  /**
   * Find pet by ID
   * Returns a single pet
   *
   * resourceId Long ID of pet to return
   * returns inline_response_200_3
   **/
  var examples = {};
  examples['application/json'] = {
  "name" : "aeiou",
  "id" : 0
};
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

exports.profileInfo = function(args, res, next) {
  /**
   * Finds Pets by status
   * Multiple status values can be provided with comma separated strings
   *
   * api_key String API KEY
   * returns List
   **/
  var examples = {};
  examples['application/json'] = [ {
  "name" : "aeiou",
  "id" : 0
} ];
  if (Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  } else {
    res.end();
  }
}

